# Ct scan > 2023-10-26 11:37am
https://universe.roboflow.com/student-jovgq/ct-scan-dgzcv

Provided by a Roboflow user
License: CC BY 4.0

